from django.apps import AppConfig


class PrivateInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'private_info'
